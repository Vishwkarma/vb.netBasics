﻿namespace InspirationDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panelHeader = new System.Windows.Forms.Panel();
            this.bunifuImageButton1 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.bunifuPictureBox1 = new Bunifu.UI.WinForms.BunifuPictureBox();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuTextBox1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCart = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnWallet = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnPayments = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnData = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnSendTckn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnDashboard = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.SidePanel = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.bunifuRadioButton5 = new Bunifu.UI.WinForms.BunifuRadioButton();
            this.bunifuRadioButton4 = new Bunifu.UI.WinForms.BunifuRadioButton();
            this.bunifuLabel16 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuRadioButton3 = new Bunifu.UI.WinForms.BunifuRadioButton();
            this.bunifuRadioButton2 = new Bunifu.UI.WinForms.BunifuRadioButton();
            this.bunifuRadioButton1 = new Bunifu.UI.WinForms.BunifuRadioButton();
            this.bunifuImageButton2 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.bunifuLabel15 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel13 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel11 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel9 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel7 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel14 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel12 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel10 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel8 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel6 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bunifuButton7 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuButton8 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuButton9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuLabel17 = new Bunifu.UI.WinForms.BunifuLabel();
            this.pnl2 = new System.Windows.Forms.Panel();
            this.bunifuButton10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuLabel22 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel19 = new Bunifu.UI.WinForms.BunifuLabel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.bunifuLabel18 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel21 = new Bunifu.UI.WinForms.BunifuLabel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.bunifuLabel20 = new Bunifu.UI.WinForms.BunifuLabel();
            this.pnl1 = new System.Windows.Forms.Panel();
            this.bunifuTextBox3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuTextBox2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.bunifuLabel24 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuButton19 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton16 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton13 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton18 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton17 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton15 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton14 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuLabel23 = new Bunifu.UI.WinForms.BunifuLabel();
            this.pnl3 = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.bunifuLabel26 = new Bunifu.UI.WinForms.BunifuLabel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.bunifuLabel25 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuFormDock1 = new Bunifu.UI.WinForms.BunifuFormDock();
            this.panelHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.pnl1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.pnl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 2;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panelHeader
            // 
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(75)))), ((int)(((byte)(105)))));
            this.panelHeader.Controls.Add(this.bunifuImageButton1);
            this.panelHeader.Controls.Add(this.bunifuPictureBox1);
            this.panelHeader.Controls.Add(this.bunifuLabel3);
            this.panelHeader.Controls.Add(this.bunifuLabel2);
            this.panelHeader.Controls.Add(this.bunifuTextBox1);
            this.panelHeader.Controls.Add(this.bunifuLabel1);
            this.panelHeader.Controls.Add(this.pictureBox1);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Location = new System.Drawing.Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(919, 51);
            this.panelHeader.TabIndex = 0;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.ActiveImage = null;
            this.bunifuImageButton1.AllowAnimations = true;
            this.bunifuImageButton1.AllowZooming = true;
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.ErrorImage")));
            this.bunifuImageButton1.FadeWhenInactive = false;
            this.bunifuImageButton1.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.ImageLocation = null;
            this.bunifuImageButton1.ImageMargin = 15;
            this.bunifuImageButton1.ImageSize = new System.Drawing.Size(17, 20);
            this.bunifuImageButton1.ImageZoomSize = new System.Drawing.Size(32, 35);
            this.bunifuImageButton1.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.InitialImage")));
            this.bunifuImageButton1.Location = new System.Drawing.Point(877, 12);
            this.bunifuImageButton1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Rotation = 0;
            this.bunifuImageButton1.ShowActiveImage = true;
            this.bunifuImageButton1.ShowCursorChanges = true;
            this.bunifuImageButton1.ShowImageBorders = false;
            this.bunifuImageButton1.ShowSizeMarkers = false;
            this.bunifuImageButton1.Size = new System.Drawing.Size(32, 35);
            this.bunifuImageButton1.TabIndex = 2;
            this.bunifuImageButton1.ToolTipText = "";
            this.bunifuImageButton1.WaitOnLoad = false;
            this.bunifuImageButton1.Zoom = 15;
            this.bunifuImageButton1.ZoomSpeed = 10;
            // 
            // bunifuPictureBox1
            // 
            this.bunifuPictureBox1.AllowFocused = false;
            this.bunifuPictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuPictureBox1.BorderRadius = 19;
            this.bunifuPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuPictureBox1.Image")));
            this.bunifuPictureBox1.IsCircle = true;
            this.bunifuPictureBox1.Location = new System.Drawing.Point(834, 8);
            this.bunifuPictureBox1.Name = "bunifuPictureBox1";
            this.bunifuPictureBox1.Size = new System.Drawing.Size(38, 38);
            this.bunifuPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuPictureBox1.TabIndex = 2;
            this.bunifuPictureBox1.TabStop = false;
            this.bunifuPictureBox1.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Square;
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = null;
            this.bunifuLabel3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(232)))), ((int)(((byte)(166)))));
            this.bunifuLabel3.Location = new System.Drawing.Point(736, 19);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(93, 19);
            this.bunifuLabel3.TabIndex = 3;
            this.bunifuLabel3.Text = "SaLaaR HuSyN";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = null;
            this.bunifuLabel2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel2.Location = new System.Drawing.Point(661, 19);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(69, 19);
            this.bunifuLabel2.TabIndex = 3;
            this.bunifuLabel2.Text = "Welcome:";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuTextBox1
            // 
            this.bunifuTextBox1.AcceptsReturn = false;
            this.bunifuTextBox1.AcceptsTab = false;
            this.bunifuTextBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox1.BackgroundImage")));
            this.bunifuTextBox1.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.bunifuTextBox1.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuTextBox1.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.bunifuTextBox1.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.bunifuTextBox1.BorderRadius = 35;
            this.bunifuTextBox1.BorderThickness = 1;
            this.bunifuTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox1.DefaultFont = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTextBox1.DefaultText = "";
            this.bunifuTextBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.bunifuTextBox1.HideSelection = true;
            this.bunifuTextBox1.IconLeft = null;
            this.bunifuTextBox1.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox1.IconPadding = 10;
            this.bunifuTextBox1.IconRight = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox1.IconRight")));
            this.bunifuTextBox1.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox1.Location = new System.Drawing.Point(227, 9);
            this.bunifuTextBox1.MaxLength = 32767;
            this.bunifuTextBox1.MinimumSize = new System.Drawing.Size(100, 35);
            this.bunifuTextBox1.Modified = false;
            this.bunifuTextBox1.Name = "bunifuTextBox1";
            this.bunifuTextBox1.PasswordChar = '\0';
            this.bunifuTextBox1.ReadOnly = false;
            this.bunifuTextBox1.SelectedText = "";
            this.bunifuTextBox1.SelectionLength = 0;
            this.bunifuTextBox1.SelectionStart = 0;
            this.bunifuTextBox1.ShortcutsEnabled = true;
            this.bunifuTextBox1.Size = new System.Drawing.Size(240, 35);
            this.bunifuTextBox1.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox1.TabIndex = 2;
            this.bunifuTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox1.TextMarginLeft = 5;
            this.bunifuTextBox1.TextPlaceholder = "What are you looking for?";
            this.bunifuTextBox1.UseSystemPasswordChar = false;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel1.Location = new System.Drawing.Point(61, 17);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(79, 21);
            this.bunifuLabel1.TabIndex = 2;
            this.bunifuLabel1.Text = "BOLDCoin";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(35, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 27);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.panel2.Controls.Add(this.btnCart);
            this.panel2.Controls.Add(this.btnWallet);
            this.panel2.Controls.Add(this.btnPayments);
            this.panel2.Controls.Add(this.btnData);
            this.panel2.Controls.Add(this.btnSendTckn);
            this.panel2.Controls.Add(this.btnDashboard);
            this.panel2.Controls.Add(this.SidePanel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 51);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(172, 483);
            this.panel2.TabIndex = 1;
            // 
            // btnCart
            // 
            this.btnCart.BackColor = System.Drawing.Color.Transparent;
            this.btnCart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCart.BackgroundImage")));
            this.btnCart.ButtonText = "Cart";
            this.btnCart.ButtonTextMarginLeft = 0;
            this.btnCart.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btnCart.DisabledFillColor = System.Drawing.Color.Gray;
            this.btnCart.DisabledForecolor = System.Drawing.Color.White;
            this.btnCart.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCart.ForeColor = System.Drawing.Color.White;
            this.btnCart.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnCart.IconPadding = 8;
            this.btnCart.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnCart.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.btnCart.IdleBorderRadius = 1;
            this.btnCart.IdleBorderThickness = 0;
            this.btnCart.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.btnCart.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnCart.IdleIconLeftImage")));
            this.btnCart.IdleIconRightImage = null;
            this.btnCart.Location = new System.Drawing.Point(8, 245);
            this.btnCart.Name = "btnCart";
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties11.BorderRadius = 1;
            stateProperties11.BorderThickness = 1;
            stateProperties11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties11.IconLeftImage = null;
            stateProperties11.IconRightImage = null;
            this.btnCart.onHoverState = stateProperties11;
            this.btnCart.Size = new System.Drawing.Size(161, 31);
            this.btnCart.TabIndex = 2;
            this.btnCart.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCart.Click += new System.EventHandler(this.btnCart_Click);
            // 
            // btnWallet
            // 
            this.btnWallet.BackColor = System.Drawing.Color.Transparent;
            this.btnWallet.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnWallet.BackgroundImage")));
            this.btnWallet.ButtonText = "Wallet";
            this.btnWallet.ButtonTextMarginLeft = 0;
            this.btnWallet.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btnWallet.DisabledFillColor = System.Drawing.Color.Gray;
            this.btnWallet.DisabledForecolor = System.Drawing.Color.White;
            this.btnWallet.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWallet.ForeColor = System.Drawing.Color.White;
            this.btnWallet.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnWallet.IconPadding = 8;
            this.btnWallet.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnWallet.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.btnWallet.IdleBorderRadius = 1;
            this.btnWallet.IdleBorderThickness = 0;
            this.btnWallet.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.btnWallet.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnWallet.IdleIconLeftImage")));
            this.btnWallet.IdleIconRightImage = null;
            this.btnWallet.Location = new System.Drawing.Point(8, 208);
            this.btnWallet.Name = "btnWallet";
            stateProperties12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties12.BorderRadius = 1;
            stateProperties12.BorderThickness = 1;
            stateProperties12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties12.IconLeftImage = null;
            stateProperties12.IconRightImage = null;
            this.btnWallet.onHoverState = stateProperties12;
            this.btnWallet.Size = new System.Drawing.Size(161, 31);
            this.btnWallet.TabIndex = 2;
            this.btnWallet.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnWallet.Click += new System.EventHandler(this.btnWallet_Click);
            // 
            // btnPayments
            // 
            this.btnPayments.BackColor = System.Drawing.Color.Transparent;
            this.btnPayments.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPayments.BackgroundImage")));
            this.btnPayments.ButtonText = "Payments";
            this.btnPayments.ButtonTextMarginLeft = 0;
            this.btnPayments.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btnPayments.DisabledFillColor = System.Drawing.Color.Gray;
            this.btnPayments.DisabledForecolor = System.Drawing.Color.White;
            this.btnPayments.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPayments.ForeColor = System.Drawing.Color.White;
            this.btnPayments.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnPayments.IconPadding = 8;
            this.btnPayments.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnPayments.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.btnPayments.IdleBorderRadius = 1;
            this.btnPayments.IdleBorderThickness = 0;
            this.btnPayments.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.btnPayments.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnPayments.IdleIconLeftImage")));
            this.btnPayments.IdleIconRightImage = null;
            this.btnPayments.Location = new System.Drawing.Point(8, 171);
            this.btnPayments.Name = "btnPayments";
            stateProperties13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties13.BorderRadius = 1;
            stateProperties13.BorderThickness = 1;
            stateProperties13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties13.IconLeftImage = null;
            stateProperties13.IconRightImage = null;
            this.btnPayments.onHoverState = stateProperties13;
            this.btnPayments.Size = new System.Drawing.Size(161, 31);
            this.btnPayments.TabIndex = 2;
            this.btnPayments.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPayments.Click += new System.EventHandler(this.btnPayments_Click);
            // 
            // btnData
            // 
            this.btnData.BackColor = System.Drawing.Color.Transparent;
            this.btnData.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnData.BackgroundImage")));
            this.btnData.ButtonText = "Data";
            this.btnData.ButtonTextMarginLeft = 0;
            this.btnData.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btnData.DisabledFillColor = System.Drawing.Color.Gray;
            this.btnData.DisabledForecolor = System.Drawing.Color.White;
            this.btnData.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnData.ForeColor = System.Drawing.Color.White;
            this.btnData.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnData.IconPadding = 8;
            this.btnData.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnData.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.btnData.IdleBorderRadius = 1;
            this.btnData.IdleBorderThickness = 0;
            this.btnData.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.btnData.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnData.IdleIconLeftImage")));
            this.btnData.IdleIconRightImage = null;
            this.btnData.Location = new System.Drawing.Point(8, 134);
            this.btnData.Name = "btnData";
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties14.BorderRadius = 1;
            stateProperties14.BorderThickness = 1;
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties14.IconLeftImage = null;
            stateProperties14.IconRightImage = null;
            this.btnData.onHoverState = stateProperties14;
            this.btnData.Size = new System.Drawing.Size(161, 31);
            this.btnData.TabIndex = 2;
            this.btnData.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnData.Click += new System.EventHandler(this.btnData_Click);
            // 
            // btnSendTckn
            // 
            this.btnSendTckn.BackColor = System.Drawing.Color.Transparent;
            this.btnSendTckn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSendTckn.BackgroundImage")));
            this.btnSendTckn.ButtonText = "Send Tokens";
            this.btnSendTckn.ButtonTextMarginLeft = 0;
            this.btnSendTckn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btnSendTckn.DisabledFillColor = System.Drawing.Color.Gray;
            this.btnSendTckn.DisabledForecolor = System.Drawing.Color.White;
            this.btnSendTckn.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSendTckn.ForeColor = System.Drawing.Color.White;
            this.btnSendTckn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnSendTckn.IconPadding = 8;
            this.btnSendTckn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnSendTckn.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.btnSendTckn.IdleBorderRadius = 1;
            this.btnSendTckn.IdleBorderThickness = 0;
            this.btnSendTckn.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.btnSendTckn.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnSendTckn.IdleIconLeftImage")));
            this.btnSendTckn.IdleIconRightImage = null;
            this.btnSendTckn.Location = new System.Drawing.Point(8, 97);
            this.btnSendTckn.Name = "btnSendTckn";
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties15.BorderRadius = 1;
            stateProperties15.BorderThickness = 1;
            stateProperties15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties15.IconLeftImage = null;
            stateProperties15.IconRightImage = null;
            this.btnSendTckn.onHoverState = stateProperties15;
            this.btnSendTckn.Size = new System.Drawing.Size(161, 31);
            this.btnSendTckn.TabIndex = 2;
            this.btnSendTckn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSendTckn.Click += new System.EventHandler(this.btnSendTckn_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.Transparent;
            this.btnDashboard.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDashboard.BackgroundImage")));
            this.btnDashboard.ButtonText = "Dashboard";
            this.btnDashboard.ButtonTextMarginLeft = 0;
            this.btnDashboard.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btnDashboard.DisabledFillColor = System.Drawing.Color.Gray;
            this.btnDashboard.DisabledForecolor = System.Drawing.Color.White;
            this.btnDashboard.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.ForeColor = System.Drawing.Color.White;
            this.btnDashboard.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnDashboard.IconPadding = 8;
            this.btnDashboard.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnDashboard.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.btnDashboard.IdleBorderRadius = 1;
            this.btnDashboard.IdleBorderThickness = 0;
            this.btnDashboard.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.btnDashboard.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnDashboard.IdleIconLeftImage")));
            this.btnDashboard.IdleIconRightImage = null;
            this.btnDashboard.Location = new System.Drawing.Point(8, 60);
            this.btnDashboard.Name = "btnDashboard";
            stateProperties16.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties16.BorderRadius = 1;
            stateProperties16.BorderThickness = 1;
            stateProperties16.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties16.IconLeftImage = null;
            stateProperties16.IconRightImage = null;
            this.btnDashboard.onHoverState = stateProperties16;
            this.btnDashboard.Size = new System.Drawing.Size(161, 31);
            this.btnDashboard.TabIndex = 2;
            this.btnDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // SidePanel
            // 
            this.SidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(232)))), ((int)(((byte)(166)))));
            this.SidePanel.Location = new System.Drawing.Point(1, 59);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(6, 32);
            this.SidePanel.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.panel4.Controls.Add(this.bunifuRadioButton5);
            this.panel4.Controls.Add(this.bunifuRadioButton4);
            this.panel4.Controls.Add(this.bunifuLabel16);
            this.panel4.Controls.Add(this.bunifuRadioButton3);
            this.panel4.Controls.Add(this.bunifuRadioButton2);
            this.panel4.Controls.Add(this.bunifuRadioButton1);
            this.panel4.Controls.Add(this.bunifuImageButton2);
            this.panel4.Controls.Add(this.bunifuLabel15);
            this.panel4.Controls.Add(this.bunifuLabel13);
            this.panel4.Controls.Add(this.bunifuLabel11);
            this.panel4.Controls.Add(this.bunifuLabel9);
            this.panel4.Controls.Add(this.bunifuLabel7);
            this.panel4.Controls.Add(this.bunifuLabel14);
            this.panel4.Controls.Add(this.bunifuLabel12);
            this.panel4.Controls.Add(this.bunifuLabel10);
            this.panel4.Controls.Add(this.bunifuLabel8);
            this.panel4.Controls.Add(this.bunifuLabel6);
            this.panel4.Controls.Add(this.bunifuLabel5);
            this.panel4.Controls.Add(this.bunifuLabel4);
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(736, 51);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(183, 483);
            this.panel4.TabIndex = 2;
            // 
            // bunifuRadioButton5
            // 
            this.bunifuRadioButton5.Checked = false;
            this.bunifuRadioButton5.Location = new System.Drawing.Point(5, 362);
            this.bunifuRadioButton5.Name = "bunifuRadioButton5";
            this.bunifuRadioButton5.OutlineColor = System.Drawing.Color.White;
            this.bunifuRadioButton5.RadioColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(232)))), ((int)(((byte)(166)))));
            this.bunifuRadioButton5.Size = new System.Drawing.Size(19, 19);
            this.bunifuRadioButton5.TabIndex = 4;
            this.bunifuRadioButton5.Text = null;
            // 
            // bunifuRadioButton4
            // 
            this.bunifuRadioButton4.Checked = false;
            this.bunifuRadioButton4.Location = new System.Drawing.Point(5, 315);
            this.bunifuRadioButton4.Name = "bunifuRadioButton4";
            this.bunifuRadioButton4.OutlineColor = System.Drawing.Color.White;
            this.bunifuRadioButton4.RadioColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(232)))), ((int)(((byte)(166)))));
            this.bunifuRadioButton4.Size = new System.Drawing.Size(19, 19);
            this.bunifuRadioButton4.TabIndex = 4;
            this.bunifuRadioButton4.Text = null;
            // 
            // bunifuLabel16
            // 
            this.bunifuLabel16.AutoEllipsis = false;
            this.bunifuLabel16.CursorType = null;
            this.bunifuLabel16.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(232)))), ((int)(((byte)(166)))));
            this.bunifuLabel16.Location = new System.Drawing.Point(110, 424);
            this.bunifuLabel16.Name = "bunifuLabel16";
            this.bunifuLabel16.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel16.Size = new System.Drawing.Size(66, 19);
            this.bunifuLabel16.TabIndex = 3;
            this.bunifuLabel16.Text = "See a Log";
            this.bunifuLabel16.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuRadioButton3
            // 
            this.bunifuRadioButton3.Checked = false;
            this.bunifuRadioButton3.Location = new System.Drawing.Point(5, 268);
            this.bunifuRadioButton3.Name = "bunifuRadioButton3";
            this.bunifuRadioButton3.OutlineColor = System.Drawing.Color.White;
            this.bunifuRadioButton3.RadioColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(232)))), ((int)(((byte)(166)))));
            this.bunifuRadioButton3.Size = new System.Drawing.Size(19, 19);
            this.bunifuRadioButton3.TabIndex = 4;
            this.bunifuRadioButton3.Text = null;
            // 
            // bunifuRadioButton2
            // 
            this.bunifuRadioButton2.Checked = false;
            this.bunifuRadioButton2.Location = new System.Drawing.Point(5, 221);
            this.bunifuRadioButton2.Name = "bunifuRadioButton2";
            this.bunifuRadioButton2.OutlineColor = System.Drawing.Color.White;
            this.bunifuRadioButton2.RadioColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(232)))), ((int)(((byte)(166)))));
            this.bunifuRadioButton2.Size = new System.Drawing.Size(19, 19);
            this.bunifuRadioButton2.TabIndex = 4;
            this.bunifuRadioButton2.Text = null;
            // 
            // bunifuRadioButton1
            // 
            this.bunifuRadioButton1.Checked = true;
            this.bunifuRadioButton1.Location = new System.Drawing.Point(5, 172);
            this.bunifuRadioButton1.Name = "bunifuRadioButton1";
            this.bunifuRadioButton1.OutlineColor = System.Drawing.Color.White;
            this.bunifuRadioButton1.RadioColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(232)))), ((int)(((byte)(166)))));
            this.bunifuRadioButton1.Size = new System.Drawing.Size(19, 19);
            this.bunifuRadioButton1.TabIndex = 4;
            this.bunifuRadioButton1.Text = null;
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.ActiveImage = null;
            this.bunifuImageButton2.AllowAnimations = true;
            this.bunifuImageButton2.AllowZooming = true;
            this.bunifuImageButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(8)))), ((int)(((byte)(123)))));
            this.bunifuImageButton2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.ErrorImage")));
            this.bunifuImageButton2.FadeWhenInactive = false;
            this.bunifuImageButton2.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.Image")));
            this.bunifuImageButton2.ImageActive = null;
            this.bunifuImageButton2.ImageLocation = null;
            this.bunifuImageButton2.ImageMargin = 15;
            this.bunifuImageButton2.ImageSize = new System.Drawing.Size(21, 16);
            this.bunifuImageButton2.ImageZoomSize = new System.Drawing.Size(36, 31);
            this.bunifuImageButton2.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.InitialImage")));
            this.bunifuImageButton2.Location = new System.Drawing.Point(76, 41);
            this.bunifuImageButton2.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Rotation = 0;
            this.bunifuImageButton2.ShowActiveImage = true;
            this.bunifuImageButton2.ShowCursorChanges = true;
            this.bunifuImageButton2.ShowImageBorders = false;
            this.bunifuImageButton2.ShowSizeMarkers = false;
            this.bunifuImageButton2.Size = new System.Drawing.Size(36, 31);
            this.bunifuImageButton2.TabIndex = 2;
            this.bunifuImageButton2.ToolTipText = "";
            this.bunifuImageButton2.WaitOnLoad = false;
            this.bunifuImageButton2.Zoom = 15;
            this.bunifuImageButton2.ZoomSpeed = 10;
            // 
            // bunifuLabel15
            // 
            this.bunifuLabel15.AutoEllipsis = false;
            this.bunifuLabel15.CursorType = null;
            this.bunifuLabel15.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel15.ForeColor = System.Drawing.Color.Silver;
            this.bunifuLabel15.Location = new System.Drawing.Point(30, 384);
            this.bunifuLabel15.Name = "bunifuLabel15";
            this.bunifuLabel15.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel15.Size = new System.Drawing.Size(84, 18);
            this.bunifuLabel15.TabIndex = 3;
            this.bunifuLabel15.Text = "30 Minutes Ago";
            this.bunifuLabel15.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel13
            // 
            this.bunifuLabel13.AutoEllipsis = false;
            this.bunifuLabel13.CursorType = null;
            this.bunifuLabel13.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel13.ForeColor = System.Drawing.Color.Silver;
            this.bunifuLabel13.Location = new System.Drawing.Point(30, 337);
            this.bunifuLabel13.Name = "bunifuLabel13";
            this.bunifuLabel13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel13.Size = new System.Drawing.Size(84, 18);
            this.bunifuLabel13.TabIndex = 3;
            this.bunifuLabel13.Text = "15 Minutes Ago";
            this.bunifuLabel13.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel11
            // 
            this.bunifuLabel11.AutoEllipsis = false;
            this.bunifuLabel11.CursorType = null;
            this.bunifuLabel11.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel11.ForeColor = System.Drawing.Color.Silver;
            this.bunifuLabel11.Location = new System.Drawing.Point(30, 290);
            this.bunifuLabel11.Name = "bunifuLabel11";
            this.bunifuLabel11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel11.Size = new System.Drawing.Size(84, 18);
            this.bunifuLabel11.TabIndex = 3;
            this.bunifuLabel11.Text = "13 Minutes Ago";
            this.bunifuLabel11.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel9
            // 
            this.bunifuLabel9.AutoEllipsis = false;
            this.bunifuLabel9.CursorType = null;
            this.bunifuLabel9.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel9.ForeColor = System.Drawing.Color.Silver;
            this.bunifuLabel9.Location = new System.Drawing.Point(30, 243);
            this.bunifuLabel9.Name = "bunifuLabel9";
            this.bunifuLabel9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel9.Size = new System.Drawing.Size(78, 18);
            this.bunifuLabel9.TabIndex = 3;
            this.bunifuLabel9.Text = "5 Minutes Ago";
            this.bunifuLabel9.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel7
            // 
            this.bunifuLabel7.AutoEllipsis = false;
            this.bunifuLabel7.CursorType = null;
            this.bunifuLabel7.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel7.ForeColor = System.Drawing.Color.Silver;
            this.bunifuLabel7.Location = new System.Drawing.Point(30, 194);
            this.bunifuLabel7.Name = "bunifuLabel7";
            this.bunifuLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel7.Size = new System.Drawing.Size(78, 18);
            this.bunifuLabel7.TabIndex = 3;
            this.bunifuLabel7.Text = "3 Minutes Ago";
            this.bunifuLabel7.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel14
            // 
            this.bunifuLabel14.AutoEllipsis = false;
            this.bunifuLabel14.CursorType = null;
            this.bunifuLabel14.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel14.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel14.Location = new System.Drawing.Point(29, 361);
            this.bunifuLabel14.Name = "bunifuLabel14";
            this.bunifuLabel14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel14.Size = new System.Drawing.Size(130, 19);
            this.bunifuLabel14.TabIndex = 3;
            this.bunifuLabel14.Text = "Logged in Dashboard";
            this.bunifuLabel14.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel12
            // 
            this.bunifuLabel12.AutoEllipsis = false;
            this.bunifuLabel12.CursorType = null;
            this.bunifuLabel12.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel12.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel12.Location = new System.Drawing.Point(29, 314);
            this.bunifuLabel12.Name = "bunifuLabel12";
            this.bunifuLabel12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel12.Size = new System.Drawing.Size(106, 19);
            this.bunifuLabel12.TabIndex = 3;
            this.bunifuLabel12.Text = "Tokens Transfered";
            this.bunifuLabel12.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel10
            // 
            this.bunifuLabel10.AutoEllipsis = false;
            this.bunifuLabel10.CursorType = null;
            this.bunifuLabel10.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel10.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel10.Location = new System.Drawing.Point(29, 267);
            this.bunifuLabel10.Name = "bunifuLabel10";
            this.bunifuLabel10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel10.Size = new System.Drawing.Size(130, 19);
            this.bunifuLabel10.TabIndex = 3;
            this.bunifuLabel10.Text = "Logged in Dashboard";
            this.bunifuLabel10.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel8
            // 
            this.bunifuLabel8.AutoEllipsis = false;
            this.bunifuLabel8.CursorType = null;
            this.bunifuLabel8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel8.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel8.Location = new System.Drawing.Point(29, 220);
            this.bunifuLabel8.Name = "bunifuLabel8";
            this.bunifuLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel8.Size = new System.Drawing.Size(120, 19);
            this.bunifuLabel8.TabIndex = 3;
            this.bunifuLabel8.Text = "You Bought Tockens";
            this.bunifuLabel8.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel6
            // 
            this.bunifuLabel6.AutoEllipsis = false;
            this.bunifuLabel6.CursorType = null;
            this.bunifuLabel6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel6.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel6.Location = new System.Drawing.Point(29, 171);
            this.bunifuLabel6.Name = "bunifuLabel6";
            this.bunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel6.Size = new System.Drawing.Size(130, 19);
            this.bunifuLabel6.TabIndex = 3;
            this.bunifuLabel6.Text = "Logged in Dashboard";
            this.bunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(8)))), ((int)(((byte)(123)))));
            this.bunifuLabel5.CursorType = null;
            this.bunifuLabel5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel5.Location = new System.Drawing.Point(70, 94);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(45, 19);
            this.bunifuLabel5.TabIndex = 3;
            this.bunifuLabel5.Text = "$51214";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(8)))), ((int)(((byte)(123)))));
            this.bunifuLabel4.CursorType = null;
            this.bunifuLabel4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel4.Location = new System.Drawing.Point(63, 74);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(65, 19);
            this.bunifuLabel4.TabIndex = 3;
            this.bunifuLabel4.Text = "My Wallet";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(38, 26);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(115, 104);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // bunifuButton7
            // 
            this.bunifuButton7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton7.BackgroundImage")));
            this.bunifuButton7.ButtonText = "Exchange Information";
            this.bunifuButton7.ButtonTextMarginLeft = 0;
            this.bunifuButton7.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton7.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton7.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton7.ForeColor = System.Drawing.Color.White;
            this.bunifuButton7.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton7.IconPadding = 6;
            this.bunifuButton7.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton7.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton7.IdleBorderRadius = 10;
            this.bunifuButton7.IdleBorderThickness = 0;
            this.bunifuButton7.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton7.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton7.IdleIconLeftImage")));
            this.bunifuButton7.IdleIconRightImage = null;
            this.bunifuButton7.Location = new System.Drawing.Point(220, 109);
            this.bunifuButton7.Name = "bunifuButton7";
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties19.BorderRadius = 1;
            stateProperties19.BorderThickness = 1;
            stateProperties19.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties19.IconLeftImage = null;
            stateProperties19.IconRightImage = null;
            this.bunifuButton7.onHoverState = stateProperties19;
            this.bunifuButton7.Size = new System.Drawing.Size(170, 26);
            this.bunifuButton7.TabIndex = 2;
            this.bunifuButton7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(391, 111);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(35, 24);
            this.bunifuSeparator1.TabIndex = 3;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // bunifuButton8
            // 
            this.bunifuButton8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton8.BackgroundImage")));
            this.bunifuButton8.ButtonText = "Wallet Details";
            this.bunifuButton8.ButtonTextMarginLeft = 0;
            this.bunifuButton8.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton8.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton8.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton8.ForeColor = System.Drawing.Color.White;
            this.bunifuButton8.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton8.IconPadding = 6;
            this.bunifuButton8.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton8.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton8.IdleBorderRadius = 10;
            this.bunifuButton8.IdleBorderThickness = 0;
            this.bunifuButton8.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton8.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton8.IdleIconLeftImage")));
            this.bunifuButton8.IdleIconRightImage = null;
            this.bunifuButton8.Location = new System.Drawing.Point(427, 109);
            this.bunifuButton8.Name = "bunifuButton8";
            stateProperties18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties18.BorderRadius = 1;
            stateProperties18.BorderThickness = 1;
            stateProperties18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties18.IconLeftImage = null;
            stateProperties18.IconRightImage = null;
            this.bunifuButton8.onHoverState = stateProperties18;
            this.bunifuButton8.Size = new System.Drawing.Size(129, 26);
            this.bunifuButton8.TabIndex = 2;
            this.bunifuButton8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(557, 109);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(40, 24);
            this.bunifuSeparator2.TabIndex = 3;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // bunifuButton9
            // 
            this.bunifuButton9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton9.BackgroundImage")));
            this.bunifuButton9.ButtonText = "Confirmation";
            this.bunifuButton9.ButtonTextMarginLeft = 0;
            this.bunifuButton9.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton9.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton9.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton9.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton9.ForeColor = System.Drawing.Color.White;
            this.bunifuButton9.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton9.IconPadding = 6;
            this.bunifuButton9.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton9.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton9.IdleBorderRadius = 10;
            this.bunifuButton9.IdleBorderThickness = 0;
            this.bunifuButton9.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton9.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton9.IdleIconLeftImage")));
            this.bunifuButton9.IdleIconRightImage = null;
            this.bunifuButton9.Location = new System.Drawing.Point(598, 107);
            this.bunifuButton9.Name = "bunifuButton9";
            stateProperties17.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties17.BorderRadius = 1;
            stateProperties17.BorderThickness = 1;
            stateProperties17.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties17.IconLeftImage = null;
            stateProperties17.IconRightImage = null;
            this.bunifuButton9.onHoverState = stateProperties17;
            this.bunifuButton9.Size = new System.Drawing.Size(122, 26);
            this.bunifuButton9.TabIndex = 2;
            this.bunifuButton9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuLabel17
            // 
            this.bunifuLabel17.AutoEllipsis = false;
            this.bunifuLabel17.CursorType = null;
            this.bunifuLabel17.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel17.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel17.Location = new System.Drawing.Point(206, 69);
            this.bunifuLabel17.Name = "bunifuLabel17";
            this.bunifuLabel17.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel17.Size = new System.Drawing.Size(132, 23);
            this.bunifuLabel17.TabIndex = 3;
            this.bunifuLabel17.Text = "Purchase Crypto";
            this.bunifuLabel17.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // pnl2
            // 
            this.pnl2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(64)))), ((int)(((byte)(254)))));
            this.pnl2.Controls.Add(this.bunifuButton10);
            this.pnl2.Controls.Add(this.bunifuLabel22);
            this.pnl2.Controls.Add(this.bunifuLabel19);
            this.pnl2.Controls.Add(this.pictureBox4);
            this.pnl2.Controls.Add(this.bunifuLabel18);
            this.pnl2.Controls.Add(this.bunifuLabel21);
            this.pnl2.Controls.Add(this.pictureBox3);
            this.pnl2.Controls.Add(this.bunifuLabel20);
            this.pnl2.Location = new System.Drawing.Point(584, 166);
            this.pnl2.Name = "pnl2";
            this.pnl2.Size = new System.Drawing.Size(135, 199);
            this.pnl2.TabIndex = 4;
            // 
            // bunifuButton10
            // 
            this.bunifuButton10.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton10.BackgroundImage")));
            this.bunifuButton10.ButtonText = "Proceed";
            this.bunifuButton10.ButtonTextMarginLeft = 0;
            this.bunifuButton10.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton10.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton10.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton10.ForeColor = System.Drawing.Color.White;
            this.bunifuButton10.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton10.IconPadding = 10;
            this.bunifuButton10.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton10.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton10.IdleBorderRadius = 32;
            this.bunifuButton10.IdleBorderThickness = 0;
            this.bunifuButton10.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton10.IdleIconLeftImage = null;
            this.bunifuButton10.IdleIconRightImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton10.IdleIconRightImage")));
            this.bunifuButton10.Location = new System.Drawing.Point(13, 157);
            this.bunifuButton10.Name = "bunifuButton10";
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties10.BorderRadius = 1;
            stateProperties10.BorderThickness = 1;
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties10.IconLeftImage = null;
            stateProperties10.IconRightImage = null;
            this.bunifuButton10.onHoverState = stateProperties10;
            this.bunifuButton10.Size = new System.Drawing.Size(110, 31);
            this.bunifuButton10.TabIndex = 5;
            this.bunifuButton10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuLabel22
            // 
            this.bunifuLabel22.AutoEllipsis = false;
            this.bunifuLabel22.CursorType = null;
            this.bunifuLabel22.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel22.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel22.Location = new System.Drawing.Point(14, 96);
            this.bunifuLabel22.Name = "bunifuLabel22";
            this.bunifuLabel22.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel22.Size = new System.Drawing.Size(76, 18);
            this.bunifuLabel22.TabIndex = 3;
            this.bunifuLabel22.Text = "You Will Earn";
            this.bunifuLabel22.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel19
            // 
            this.bunifuLabel19.AutoEllipsis = false;
            this.bunifuLabel19.CursorType = null;
            this.bunifuLabel19.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel19.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel19.Location = new System.Drawing.Point(11, 41);
            this.bunifuLabel19.Name = "bunifuLabel19";
            this.bunifuLabel19.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel19.Size = new System.Drawing.Size(98, 18);
            this.bunifuLabel19.TabIndex = 3;
            this.bunifuLabel19.Text = "You Have to Pay";
            this.bunifuLabel19.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(11, 123);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(19, 22);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // bunifuLabel18
            // 
            this.bunifuLabel18.AutoEllipsis = false;
            this.bunifuLabel18.CursorType = null;
            this.bunifuLabel18.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel18.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel18.Location = new System.Drawing.Point(11, 9);
            this.bunifuLabel18.Name = "bunifuLabel18";
            this.bunifuLabel18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel18.Size = new System.Drawing.Size(64, 18);
            this.bunifuLabel18.TabIndex = 3;
            this.bunifuLabel18.Text = "PAYMENTS";
            this.bunifuLabel18.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuLabel21
            // 
            this.bunifuLabel21.AutoEllipsis = false;
            this.bunifuLabel21.CursorType = null;
            this.bunifuLabel21.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel21.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel21.Location = new System.Drawing.Point(38, 125);
            this.bunifuLabel21.Name = "bunifuLabel21";
            this.bunifuLabel21.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel21.Size = new System.Drawing.Size(31, 19);
            this.bunifuLabel21.TabIndex = 3;
            this.bunifuLabel21.Text = "1324";
            this.bunifuLabel21.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(8, 68);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(19, 22);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // bunifuLabel20
            // 
            this.bunifuLabel20.AutoEllipsis = false;
            this.bunifuLabel20.CursorType = null;
            this.bunifuLabel20.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel20.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel20.Location = new System.Drawing.Point(37, 70);
            this.bunifuLabel20.Name = "bunifuLabel20";
            this.bunifuLabel20.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel20.Size = new System.Drawing.Size(24, 19);
            this.bunifuLabel20.TabIndex = 3;
            this.bunifuLabel20.Text = "233";
            this.bunifuLabel20.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // pnl1
            // 
            this.pnl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(54)))), ((int)(((byte)(78)))));
            this.pnl1.Controls.Add(this.bunifuTextBox3);
            this.pnl1.Controls.Add(this.bunifuTextBox2);
            this.pnl1.Controls.Add(this.panel7);
            this.pnl1.Controls.Add(this.bunifuLabel23);
            this.pnl1.Location = new System.Drawing.Point(206, 163);
            this.pnl1.Name = "pnl1";
            this.pnl1.Size = new System.Drawing.Size(363, 202);
            this.pnl1.TabIndex = 5;
            // 
            // bunifuTextBox3
            // 
            this.bunifuTextBox3.AcceptsReturn = false;
            this.bunifuTextBox3.AcceptsTab = false;
            this.bunifuTextBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox3.BackgroundImage")));
            this.bunifuTextBox3.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.bunifuTextBox3.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuTextBox3.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.bunifuTextBox3.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuTextBox3.BorderRadius = 18;
            this.bunifuTextBox3.BorderThickness = 1;
            this.bunifuTextBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox3.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTextBox3.DefaultText = "";
            this.bunifuTextBox3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.bunifuTextBox3.HideSelection = true;
            this.bunifuTextBox3.IconLeft = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox3.IconLeft")));
            this.bunifuTextBox3.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox3.IconPadding = 10;
            this.bunifuTextBox3.IconRight = null;
            this.bunifuTextBox3.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox3.Location = new System.Drawing.Point(14, 109);
            this.bunifuTextBox3.MaxLength = 32767;
            this.bunifuTextBox3.MinimumSize = new System.Drawing.Size(100, 35);
            this.bunifuTextBox3.Modified = false;
            this.bunifuTextBox3.Name = "bunifuTextBox3";
            this.bunifuTextBox3.PasswordChar = '\0';
            this.bunifuTextBox3.ReadOnly = false;
            this.bunifuTextBox3.SelectedText = "";
            this.bunifuTextBox3.SelectionLength = 0;
            this.bunifuTextBox3.SelectionStart = 0;
            this.bunifuTextBox3.ShortcutsEnabled = true;
            this.bunifuTextBox3.Size = new System.Drawing.Size(160, 35);
            this.bunifuTextBox3.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox3.TabIndex = 1;
            this.bunifuTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox3.TextMarginLeft = 5;
            this.bunifuTextBox3.TextPlaceholder = "BTP";
            this.bunifuTextBox3.UseSystemPasswordChar = false;
            // 
            // bunifuTextBox2
            // 
            this.bunifuTextBox2.AcceptsReturn = false;
            this.bunifuTextBox2.AcceptsTab = false;
            this.bunifuTextBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox2.BackgroundImage")));
            this.bunifuTextBox2.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.bunifuTextBox2.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuTextBox2.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.bunifuTextBox2.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuTextBox2.BorderRadius = 18;
            this.bunifuTextBox2.BorderThickness = 1;
            this.bunifuTextBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox2.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTextBox2.DefaultText = "";
            this.bunifuTextBox2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.bunifuTextBox2.HideSelection = true;
            this.bunifuTextBox2.IconLeft = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox2.IconLeft")));
            this.bunifuTextBox2.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox2.IconPadding = 10;
            this.bunifuTextBox2.IconRight = null;
            this.bunifuTextBox2.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuTextBox2.Location = new System.Drawing.Point(14, 47);
            this.bunifuTextBox2.MaxLength = 32767;
            this.bunifuTextBox2.MinimumSize = new System.Drawing.Size(100, 35);
            this.bunifuTextBox2.Modified = false;
            this.bunifuTextBox2.Name = "bunifuTextBox2";
            this.bunifuTextBox2.PasswordChar = '\0';
            this.bunifuTextBox2.ReadOnly = false;
            this.bunifuTextBox2.SelectedText = "";
            this.bunifuTextBox2.SelectionLength = 0;
            this.bunifuTextBox2.SelectionStart = 0;
            this.bunifuTextBox2.ShortcutsEnabled = true;
            this.bunifuTextBox2.Size = new System.Drawing.Size(160, 35);
            this.bunifuTextBox2.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox2.TabIndex = 1;
            this.bunifuTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox2.TextMarginLeft = 5;
            this.bunifuTextBox2.TextPlaceholder = "USD";
            this.bunifuTextBox2.UseSystemPasswordChar = false;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.panel7.Controls.Add(this.bunifuLabel24);
            this.panel7.Controls.Add(this.bunifuButton19);
            this.panel7.Controls.Add(this.bunifuButton16);
            this.panel7.Controls.Add(this.bunifuButton13);
            this.panel7.Controls.Add(this.bunifuButton18);
            this.panel7.Controls.Add(this.bunifuButton17);
            this.panel7.Controls.Add(this.bunifuButton15);
            this.panel7.Controls.Add(this.bunifuButton14);
            this.panel7.Controls.Add(this.bunifuButton12);
            this.panel7.Controls.Add(this.bunifuButton11);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel7.Location = new System.Drawing.Point(185, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(178, 202);
            this.panel7.TabIndex = 0;
            // 
            // bunifuLabel24
            // 
            this.bunifuLabel24.AutoEllipsis = false;
            this.bunifuLabel24.CursorType = null;
            this.bunifuLabel24.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel24.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel24.Location = new System.Drawing.Point(9, 13);
            this.bunifuLabel24.Name = "bunifuLabel24";
            this.bunifuLabel24.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel24.Size = new System.Drawing.Size(134, 18);
            this.bunifuLabel24.TabIndex = 3;
            this.bunifuLabel24.Text = "Select Cryptocurrency";
            this.bunifuLabel24.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuButton19
            // 
            this.bunifuButton19.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton19.BackgroundImage")));
            this.bunifuButton19.ButtonText = "Abc";
            this.bunifuButton19.ButtonTextMarginLeft = 0;
            this.bunifuButton19.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton19.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton19.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton19.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton19.ForeColor = System.Drawing.Color.White;
            this.bunifuButton19.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton19.IconPadding = 6;
            this.bunifuButton19.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton19.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton19.IdleBorderRadius = 10;
            this.bunifuButton19.IdleBorderThickness = 0;
            this.bunifuButton19.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton19.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton19.IdleIconLeftImage")));
            this.bunifuButton19.IdleIconRightImage = null;
            this.bunifuButton19.Location = new System.Drawing.Point(115, 135);
            this.bunifuButton19.Name = "bunifuButton19";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties1.BorderRadius = 1;
            stateProperties1.BorderThickness = 1;
            stateProperties1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties1.IconLeftImage = null;
            stateProperties1.IconRightImage = null;
            this.bunifuButton19.onHoverState = stateProperties1;
            this.bunifuButton19.Size = new System.Drawing.Size(38, 36);
            this.bunifuButton19.TabIndex = 2;
            this.bunifuButton19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuButton16
            // 
            this.bunifuButton16.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton16.BackgroundImage")));
            this.bunifuButton16.ButtonText = "Abc";
            this.bunifuButton16.ButtonTextMarginLeft = 0;
            this.bunifuButton16.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton16.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton16.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton16.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton16.ForeColor = System.Drawing.Color.White;
            this.bunifuButton16.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton16.IconPadding = 6;
            this.bunifuButton16.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton16.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton16.IdleBorderRadius = 10;
            this.bunifuButton16.IdleBorderThickness = 0;
            this.bunifuButton16.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton16.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton16.IdleIconLeftImage")));
            this.bunifuButton16.IdleIconRightImage = null;
            this.bunifuButton16.Location = new System.Drawing.Point(115, 93);
            this.bunifuButton16.Name = "bunifuButton16";
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties2.BorderRadius = 1;
            stateProperties2.BorderThickness = 1;
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties2.IconLeftImage = null;
            stateProperties2.IconRightImage = null;
            this.bunifuButton16.onHoverState = stateProperties2;
            this.bunifuButton16.Size = new System.Drawing.Size(38, 36);
            this.bunifuButton16.TabIndex = 2;
            this.bunifuButton16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuButton13
            // 
            this.bunifuButton13.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton13.BackgroundImage")));
            this.bunifuButton13.ButtonText = "Abc";
            this.bunifuButton13.ButtonTextMarginLeft = 0;
            this.bunifuButton13.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton13.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton13.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton13.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton13.ForeColor = System.Drawing.Color.White;
            this.bunifuButton13.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton13.IconPadding = 6;
            this.bunifuButton13.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton13.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton13.IdleBorderRadius = 10;
            this.bunifuButton13.IdleBorderThickness = 0;
            this.bunifuButton13.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton13.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton13.IdleIconLeftImage")));
            this.bunifuButton13.IdleIconRightImage = null;
            this.bunifuButton13.Location = new System.Drawing.Point(115, 51);
            this.bunifuButton13.Name = "bunifuButton13";
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties3.BorderRadius = 1;
            stateProperties3.BorderThickness = 1;
            stateProperties3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties3.IconLeftImage = null;
            stateProperties3.IconRightImage = null;
            this.bunifuButton13.onHoverState = stateProperties3;
            this.bunifuButton13.Size = new System.Drawing.Size(38, 36);
            this.bunifuButton13.TabIndex = 2;
            this.bunifuButton13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuButton18
            // 
            this.bunifuButton18.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton18.BackgroundImage")));
            this.bunifuButton18.ButtonText = "Abc";
            this.bunifuButton18.ButtonTextMarginLeft = 0;
            this.bunifuButton18.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton18.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton18.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton18.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton18.ForeColor = System.Drawing.Color.White;
            this.bunifuButton18.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton18.IconPadding = 6;
            this.bunifuButton18.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton18.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton18.IdleBorderRadius = 10;
            this.bunifuButton18.IdleBorderThickness = 0;
            this.bunifuButton18.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton18.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton18.IdleIconLeftImage")));
            this.bunifuButton18.IdleIconRightImage = null;
            this.bunifuButton18.Location = new System.Drawing.Point(68, 135);
            this.bunifuButton18.Name = "bunifuButton18";
            stateProperties4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties4.BorderRadius = 1;
            stateProperties4.BorderThickness = 1;
            stateProperties4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties4.IconLeftImage = null;
            stateProperties4.IconRightImage = null;
            this.bunifuButton18.onHoverState = stateProperties4;
            this.bunifuButton18.Size = new System.Drawing.Size(38, 36);
            this.bunifuButton18.TabIndex = 2;
            this.bunifuButton18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuButton17
            // 
            this.bunifuButton17.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton17.BackgroundImage")));
            this.bunifuButton17.ButtonText = "Abc";
            this.bunifuButton17.ButtonTextMarginLeft = 0;
            this.bunifuButton17.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton17.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton17.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton17.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton17.ForeColor = System.Drawing.Color.White;
            this.bunifuButton17.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton17.IconPadding = 6;
            this.bunifuButton17.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton17.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton17.IdleBorderRadius = 10;
            this.bunifuButton17.IdleBorderThickness = 0;
            this.bunifuButton17.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton17.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton17.IdleIconLeftImage")));
            this.bunifuButton17.IdleIconRightImage = null;
            this.bunifuButton17.Location = new System.Drawing.Point(24, 135);
            this.bunifuButton17.Name = "bunifuButton17";
            stateProperties5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties5.BorderRadius = 1;
            stateProperties5.BorderThickness = 1;
            stateProperties5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties5.IconLeftImage = null;
            stateProperties5.IconRightImage = null;
            this.bunifuButton17.onHoverState = stateProperties5;
            this.bunifuButton17.Size = new System.Drawing.Size(38, 36);
            this.bunifuButton17.TabIndex = 2;
            this.bunifuButton17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuButton15
            // 
            this.bunifuButton15.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton15.BackgroundImage")));
            this.bunifuButton15.ButtonText = "Abc";
            this.bunifuButton15.ButtonTextMarginLeft = 0;
            this.bunifuButton15.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton15.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton15.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton15.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton15.ForeColor = System.Drawing.Color.White;
            this.bunifuButton15.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton15.IconPadding = 6;
            this.bunifuButton15.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton15.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton15.IdleBorderRadius = 10;
            this.bunifuButton15.IdleBorderThickness = 0;
            this.bunifuButton15.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton15.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton15.IdleIconLeftImage")));
            this.bunifuButton15.IdleIconRightImage = null;
            this.bunifuButton15.Location = new System.Drawing.Point(68, 93);
            this.bunifuButton15.Name = "bunifuButton15";
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties6.BorderRadius = 1;
            stateProperties6.BorderThickness = 1;
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties6.IconLeftImage = null;
            stateProperties6.IconRightImage = null;
            this.bunifuButton15.onHoverState = stateProperties6;
            this.bunifuButton15.Size = new System.Drawing.Size(38, 36);
            this.bunifuButton15.TabIndex = 2;
            this.bunifuButton15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuButton14
            // 
            this.bunifuButton14.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton14.BackgroundImage")));
            this.bunifuButton14.ButtonText = "Abc";
            this.bunifuButton14.ButtonTextMarginLeft = 0;
            this.bunifuButton14.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton14.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton14.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton14.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton14.ForeColor = System.Drawing.Color.White;
            this.bunifuButton14.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton14.IconPadding = 6;
            this.bunifuButton14.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton14.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton14.IdleBorderRadius = 10;
            this.bunifuButton14.IdleBorderThickness = 0;
            this.bunifuButton14.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton14.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton14.IdleIconLeftImage")));
            this.bunifuButton14.IdleIconRightImage = null;
            this.bunifuButton14.Location = new System.Drawing.Point(24, 93);
            this.bunifuButton14.Name = "bunifuButton14";
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties7.BorderRadius = 1;
            stateProperties7.BorderThickness = 1;
            stateProperties7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties7.IconLeftImage = null;
            stateProperties7.IconRightImage = null;
            this.bunifuButton14.onHoverState = stateProperties7;
            this.bunifuButton14.Size = new System.Drawing.Size(38, 36);
            this.bunifuButton14.TabIndex = 2;
            this.bunifuButton14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuButton12
            // 
            this.bunifuButton12.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton12.BackgroundImage")));
            this.bunifuButton12.ButtonText = "Abc";
            this.bunifuButton12.ButtonTextMarginLeft = 0;
            this.bunifuButton12.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton12.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton12.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton12.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton12.ForeColor = System.Drawing.Color.White;
            this.bunifuButton12.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton12.IconPadding = 6;
            this.bunifuButton12.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton12.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton12.IdleBorderRadius = 10;
            this.bunifuButton12.IdleBorderThickness = 0;
            this.bunifuButton12.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton12.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton12.IdleIconLeftImage")));
            this.bunifuButton12.IdleIconRightImage = null;
            this.bunifuButton12.Location = new System.Drawing.Point(68, 51);
            this.bunifuButton12.Name = "bunifuButton12";
            stateProperties8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties8.BorderRadius = 1;
            stateProperties8.BorderThickness = 1;
            stateProperties8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties8.IconLeftImage = null;
            stateProperties8.IconRightImage = null;
            this.bunifuButton12.onHoverState = stateProperties8;
            this.bunifuButton12.Size = new System.Drawing.Size(38, 36);
            this.bunifuButton12.TabIndex = 2;
            this.bunifuButton12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuButton11
            // 
            this.bunifuButton11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton11.BackgroundImage")));
            this.bunifuButton11.ButtonText = "Abc";
            this.bunifuButton11.ButtonTextMarginLeft = 0;
            this.bunifuButton11.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton11.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton11.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton11.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton11.ForeColor = System.Drawing.Color.White;
            this.bunifuButton11.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton11.IconPadding = 6;
            this.bunifuButton11.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton11.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton11.IdleBorderRadius = 10;
            this.bunifuButton11.IdleBorderThickness = 0;
            this.bunifuButton11.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(49)))), ((int)(((byte)(69)))));
            this.bunifuButton11.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton11.IdleIconLeftImage")));
            this.bunifuButton11.IdleIconRightImage = null;
            this.bunifuButton11.Location = new System.Drawing.Point(24, 51);
            this.bunifuButton11.Name = "bunifuButton11";
            stateProperties9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties9.BorderRadius = 1;
            stateProperties9.BorderThickness = 1;
            stateProperties9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties9.IconLeftImage = null;
            stateProperties9.IconRightImage = null;
            this.bunifuButton11.onHoverState = stateProperties9;
            this.bunifuButton11.Size = new System.Drawing.Size(38, 36);
            this.bunifuButton11.TabIndex = 2;
            this.bunifuButton11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuLabel23
            // 
            this.bunifuLabel23.AutoEllipsis = false;
            this.bunifuLabel23.CursorType = null;
            this.bunifuLabel23.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel23.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel23.Location = new System.Drawing.Point(14, 12);
            this.bunifuLabel23.Name = "bunifuLabel23";
            this.bunifuLabel23.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel23.Size = new System.Drawing.Size(79, 18);
            this.bunifuLabel23.TabIndex = 3;
            this.bunifuLabel23.Text = "Purchase IVY";
            this.bunifuLabel23.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // pnl3
            // 
            this.pnl3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(42)))), ((int)(((byte)(92)))));
            this.pnl3.Controls.Add(this.pictureBox6);
            this.pnl3.Controls.Add(this.bunifuLabel26);
            this.pnl3.Controls.Add(this.pictureBox5);
            this.pnl3.Controls.Add(this.bunifuLabel25);
            this.pnl3.Location = new System.Drawing.Point(207, 378);
            this.pnl3.Name = "pnl3";
            this.pnl3.Size = new System.Drawing.Size(363, 35);
            this.pnl3.TabIndex = 6;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(185, 6);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(19, 22);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 2;
            this.pictureBox6.TabStop = false;
            // 
            // bunifuLabel26
            // 
            this.bunifuLabel26.AutoEllipsis = false;
            this.bunifuLabel26.CursorType = null;
            this.bunifuLabel26.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel26.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel26.Location = new System.Drawing.Point(209, 8);
            this.bunifuLabel26.Name = "bunifuLabel26";
            this.bunifuLabel26.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel26.Size = new System.Drawing.Size(107, 18);
            this.bunifuLabel26.TabIndex = 3;
            this.bunifuLabel26.Text = "43545 Total Amount";
            this.bunifuLabel26.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(10, 6);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(19, 22);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // bunifuLabel25
            // 
            this.bunifuLabel25.AutoEllipsis = false;
            this.bunifuLabel25.CursorType = null;
            this.bunifuLabel25.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel25.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel25.Location = new System.Drawing.Point(34, 8);
            this.bunifuLabel25.Name = "bunifuLabel25";
            this.bunifuLabel25.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel25.Size = new System.Drawing.Size(90, 18);
            this.bunifuLabel25.TabIndex = 3;
            this.bunifuLabel25.Text = "124 Transactions";
            this.bunifuLabel25.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.panelHeader;
            this.bunifuDragControl1.Vertical = true;
            // 
            // bunifuFormDock1
            // 
            this.bunifuFormDock1.AllowFormDragging = true;
            this.bunifuFormDock1.AllowFormResizing = true;
            this.bunifuFormDock1.AllowOpacityChangesWhileDragging = true;
            this.bunifuFormDock1.ContainerControl = this;
            this.bunifuFormDock1.DockingIndicatorsColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(215)))), ((int)(((byte)(233)))));
            this.bunifuFormDock1.DockingIndicatorsOpacity = 0.5D;
            this.bunifuFormDock1.DockingOptions.DockAll = true;
            this.bunifuFormDock1.DockingOptions.DockBottomLeft = true;
            this.bunifuFormDock1.DockingOptions.DockBottomRight = true;
            this.bunifuFormDock1.DockingOptions.DockFullScreen = true;
            this.bunifuFormDock1.DockingOptions.DockLeft = true;
            this.bunifuFormDock1.DockingOptions.DockRight = true;
            this.bunifuFormDock1.DockingOptions.DockTopLeft = true;
            this.bunifuFormDock1.DockingOptions.DockTopRight = true;
            this.bunifuFormDock1.FormDraggingOpacity = 0.8D;
            this.bunifuFormDock1.ParentForm = this;
            this.bunifuFormDock1.ShowCursorChanges = true;
            this.bunifuFormDock1.ShowDockingIndicators = true;
            this.bunifuFormDock1.TitleBarOptions.AllowFormDragging = true;
            this.bunifuFormDock1.TitleBarOptions.BunifuFormDock = this.bunifuFormDock1;
            this.bunifuFormDock1.TitleBarOptions.DoubleClickToExpandWindow = true;
            this.bunifuFormDock1.TitleBarOptions.TitleBarControl = null;
            this.bunifuFormDock1.TitleBarOptions.UseBackColorOnDockingIndicators = false;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(919, 534);
            this.Controls.Add(this.pnl3);
            this.Controls.Add(this.pnl1);
            this.Controls.Add(this.pnl2);
            this.Controls.Add(this.bunifuSeparator2);
            this.Controls.Add(this.bunifuSeparator1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.bunifuLabel17);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelHeader);
            this.Controls.Add(this.bunifuButton9);
            this.Controls.Add(this.bunifuButton8);
            this.Controls.Add(this.bunifuButton7);
            this.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnl2.ResumeLayout(false);
            this.pnl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.pnl1.ResumeLayout(false);
            this.pnl1.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.pnl3.ResumeLayout(false);
            this.pnl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.UI.WinForms.BunifuRadioButton bunifuRadioButton5;
        private Bunifu.UI.WinForms.BunifuRadioButton bunifuRadioButton4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel16;
        private Bunifu.UI.WinForms.BunifuRadioButton bunifuRadioButton3;
        private Bunifu.UI.WinForms.BunifuRadioButton bunifuRadioButton2;
        private Bunifu.UI.WinForms.BunifuRadioButton bunifuRadioButton1;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel15;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel13;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel11;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel9;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel7;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel14;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel12;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel10;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel8;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel6;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnCart;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnWallet;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnPayments;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnData;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnSendTckn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnDashboard;
        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.Panel panelHeader;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton1;
        private Bunifu.UI.WinForms.BunifuPictureBox bunifuPictureBox1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnl3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel26;
        private System.Windows.Forms.PictureBox pictureBox5;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel25;
        private System.Windows.Forms.Panel pnl1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox3;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox2;
        private System.Windows.Forms.Panel panel7;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel24;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton19;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton16;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton13;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton18;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton17;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton15;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton14;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton12;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton11;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel23;
        private System.Windows.Forms.Panel pnl2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton10;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel22;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel19;
        private System.Windows.Forms.PictureBox pictureBox4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel18;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel21;
        private System.Windows.Forms.PictureBox pictureBox3;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel20;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel17;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton9;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton8;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton7;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.UI.WinForms.BunifuFormDock bunifuFormDock1;
    }
}

